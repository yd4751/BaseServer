ConfigRoomManager = {
    RoomBegin = 1,
    RoomEnd = 1,
}