require("Common.class")
local BaseRoom = require("Room.BaseRoom")

local Room = class(BaseRoom)

function Room:Login(pUser)
    self:super(Room, "Login",pUser);
    --此处添加代码
    --...

end
function Room:Logout(pUser)
    --此处添加代码
    --...

    return self:super(Room, "Logout",pUser);
end
return Room