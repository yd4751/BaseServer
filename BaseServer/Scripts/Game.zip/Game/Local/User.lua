require("Common.class")
local BaseUser = require("User.BaseUser")

local User = class(BaseUser)

return User