ClientRequest = {
    ROOM_LOGIN = 1000,
    ROOM_LOGOUT = 1001,
}

ServerReply = {
    ROOM_LOGIN = 2000,
    ROOM_LOGOUT = 2001,
}