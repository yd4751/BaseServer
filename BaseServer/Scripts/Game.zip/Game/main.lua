require("RoomManager.BaseRoomManager")

local m_BaseRoomManager = nil 

function OnDisconnect(uid)
    print("[Lua] Disconnect",uid)
    m_BaseRoomManager:OnDisconnect(uid)
end

function OnReconnect(uid)
    print("[Lua] Reconnect",uid)
    m_BaseRoomManager:OnReconnect(uid)
end

function OnUpdateUserInfo(uid,info)
    print("[Lua] UpdateUserInfo",uid,info)
    m_BaseRoomManager:OnUpdateUserInfo(uid,info)
end

function OnMessage( uid,cmd,message )
	print("[Lua] OnMessage",uid,cmd,message)
	return m_BaseRoomManager:OnMessage(uid,cmd,message)
end

function Init()
	print("[Lua] Init")
	--Log("Init)
    m_BaseRoomManager = BaseRoomManager.new()
    m_BaseRoomManager:Init()
end

Init()
--
OnMessage(123456,ClientRequest.ROOM_LOGIN,nil)
OnMessage(123456,ClientRequest.ROOM_LOGOUT,nil)
--[[
	--c++ part
	UpdatePlaying(uid)
	UpdateExited(uid)
	UpdateUserInfo(uid,info)
	SendData(uid,cmd,message)

	--lua part
	OnMessage( uid,message )
	OnDisconnect(uid)
	OnReconnect(uid)
	OnUpdateUserInfo(uid,info)
]]